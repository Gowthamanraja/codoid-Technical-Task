

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import p1.UserBean;

/**
 * Servlet implementation class for Servlet: RegisterServlet
 *
 */
 public class SignupServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SignupServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		UserBean o=new UserBean();
		o.setFirstname(firstname);
		o.setLastname(lastname);
		o.setUsername(username);
		o.setPassword(password);
		SignupAction ra=new SignupAction();
		boolean status=ra.Registerdetails(o);
		if(status){
			RequestDispatcher r=getServletContext().getRequestDispatcher("/SignupSuccess.jsp");
			r.forward(request,response);
		}else{
			response.sendRedirect("SignupUnSuccess.jsp");
		}
	}   	  	    
}