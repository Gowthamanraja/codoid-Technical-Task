import java.sql.*;
import p1.UserBean;
public class SignupAction {
	public boolean Registerdetails(UserBean b){
		boolean status=false;
		String firstname=b.getFirstname();
		String lastname=b.getLastname();
		String username=b.getUsername();
		String password=b.getPassword();
		Connection con =null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","login","login");
			Statement s=con.createStatement();
			ResultSet r=s.executeQuery("select * from userdata where username='"+username+"'and password='"+password+"'");
			if(r.next()){
				status=false;
			}else{
				int i=s.executeUpdate("insert into userdata(firstname,lastname,username,password)values('"+firstname+"','"+lastname+"','"+username+"','"+password+"')");
				if(i>0){
					status=true;
				}
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return status;
	}
}
