import java.sql.*;
public class SigninAction {
	public boolean userdata(String username,String password){
		boolean status=false;
		Connection con=null;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","login","login");
			Statement s=con.createStatement();
			ResultSet r=s.executeQuery("select * from userdata where username='"+username+"'and password='"+password+"'");
			while(r.next()){
				status=true;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return status;
	}
}
